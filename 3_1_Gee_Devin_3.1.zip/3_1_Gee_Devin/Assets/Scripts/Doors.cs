using UnityEngine;
using System.Collections;

public class Doors : MonoBehaviour {
	public bool doorClose	= true;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	//void Update () {
		//if (doorClose = false && (collider."open")){
			// keep open 
			// close after away from collider
		//}
		//else(doorClose = true && ((collider."open")){
			//open the door
			//reamain open while in collider
		//}
	//}		
}